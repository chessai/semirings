`star`

http://r6.ca/blog/20110808T035622Z.html
